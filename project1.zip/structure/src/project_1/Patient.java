package project_1;
public class Patient {
	 int patientID;
	    String fullName;
	    int age;
	    String department;
	    float billAmount;

	    public Patient(int id, String name, int age, String dept, float bill) {
	        this.patientID = id;
	        this.fullName = name;
	        this.age = age;
	        this.department = dept;
	        this.billAmount = bill;
	    }
	}


